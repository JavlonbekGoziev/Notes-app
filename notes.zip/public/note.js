const addButton = document.getElementById('addButton');
const taskInput = document.getElementById('taskInput');
const noteList = document.getElementById('noteList');

function loadNotes() {
    const notes = JSON.parse(localStorage.getItem('notes')) || [];
    noteList.innerHTML = ''; // Clear the existing notes

    notes.forEach((note, index) => {
        const li = document.createElement('li');

        const label = document.createElement('label');
        label.textContent = note.task;
        if (note.completed) {
            label.classList.add('completed'); // Add strikethrough if completed
        }

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = note.completed;
        checkbox.addEventListener('change', () => {
            note.completed = checkbox.checked;
            label.classList.toggle('completed', checkbox.checked); // Toggle strikethrough
            saveNotes(); // Save changes to local storage
        });

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.onclick = () => {
            deleteNote(index); // Call the deleteNote function
        };

        // Append elements in the desired order
        li.appendChild(label); // Label first
        li.appendChild(checkbox); // Checkbox second
        li.appendChild(deleteButton); // Delete button last

        noteList.appendChild(li);
    });
}

function saveNotes() {
    const notes = Array.from(noteList.children).map(li => {
        return {
            task: li.querySelector('label').textContent,
            completed: li.querySelector('input[type="checkbox"]').checked
        };
    });
    localStorage.setItem('notes', JSON.stringify(notes)); // Save to local storage
}

function deleteNote(index) {
    const notes = JSON.parse(localStorage.getItem('notes')) || [];
    notes.splice(index, 1); // Remove note from the array
    localStorage.setItem('notes', JSON.stringify(notes)); // Update local storage
    loadNotes(); // Refresh the note list
}

addButton.addEventListener('click', () => {
    const task = taskInput.value.trim(); // Trim whitespace
    if (task) {
        const notes = JSON.parse(localStorage.getItem('notes')) || [];
        notes.push({ task, completed: false }); // Add new note
        localStorage.setItem('notes', JSON.stringify(notes)); // Save to local storage
        taskInput.value = ''; // Clear input field
        loadNotes(); // Refresh the note list
    }
});

loadNotes(); // Load notes on page load
